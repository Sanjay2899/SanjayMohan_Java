package Question1;

import java.io.Serializable;

public class Project implements Serializable {

	private static final long serialversionUID=2L;
	
	String projectCode;
	String projectName ; 
	int projectStrength;
	public Project(String projectCode, String projectName, int projectStrength) {
		super();
		this.projectCode = projectCode;
		this.projectName = projectName;
		this.projectStrength = projectStrength;
	}
	

}
