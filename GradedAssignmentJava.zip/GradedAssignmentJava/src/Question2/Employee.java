package Question2;

import java.io.Serializable;

public class Employee implements Serializable {

	private static final long serialversionUID=1L;

	
	String EmployeeId;
	String EmployeeName;
	String EmployeePhone;  
	String EmployeeAddress;  
	int EmployeeSalary;
	public Employee(String employeeId, String employeeName, String employeePhone, String employeeAddress,
			int employeeSalary) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		EmployeePhone = employeePhone;
		EmployeeAddress = employeeAddress;
		EmployeeSalary = employeeSalary;
	}
	
	 

}
