package Question2;

import java.util.ArrayList;
import java.util.Map;

public class Thread1 {

public Map<Project, ArrayList<Employee>> projectMap;
    

    public Thread1(Map<Project, ArrayList<Employee>> projectMap) {
        this.projectMap = projectMap;
        
    }
}
