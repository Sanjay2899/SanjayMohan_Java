package Question2;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Map;

public class consumer extends Thread {
		Thread1 t1;
	
	public consumer(Thread1 t1) {
		super();
		this.t1 = t1;
		
	}

	@SuppressWarnings("unchecked")
	public void run()
	{
		try {
			
            synchronized (t1) {
            	
            	t1.wait();
            	
            	FileInputStream files1=new FileInputStream("sample1.txt");
        		ObjectInputStream ois=new ObjectInputStream(files1);
            	t1.projectMap.clear();
                t1.projectMap= (Map<Project, ArrayList<Employee>>) ois.readObject();
                System.out.println("DeSerialized Called by Consumer");
                System.out.print("DeSerialized Data : ");
                for (Map.Entry<Project, ArrayList<Employee>> entry : t1.projectMap.entrySet()) {
		            Project key = entry.getKey();
		            ArrayList<Employee> employees = entry.getValue();
		        
				
				System.out.println("Project [projectCode= "+key.projectCode+", projectName= "+key.projectName+", projectStrength="+key.projectStrength+"] Has the\r\n"
						+ "following Employees");
				System.out.println("Employees...");
				System.out.print("[Employee ");
				for(Employee emp: employees)
				{
					
					System.out.print("[employeeId="+emp.EmployeeId+", employeeName="+emp.EmployeeName+", employeePhone="+emp.EmployeePhone+",\r\n"
							+ "employeeAddress="+emp.EmployeeAddress+", employeeSalary="+emp.EmployeeSalary+"]");
				}
				System.out.print("]");
				System.out.println();
				
			}
                
                
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

}
