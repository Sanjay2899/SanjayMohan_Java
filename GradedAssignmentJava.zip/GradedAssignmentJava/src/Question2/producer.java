package Question2;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Map;

public class producer extends Thread {
	
	Thread1 t1;
	
	public producer(Thread1 t1) {
		super();
		this.t1 = t1;
		
	}
	
	public void run()
	{
		try {
			
            synchronized (t1) {
            	
            	FileOutputStream file1=new FileOutputStream("sample1.txt");
            	
            	ObjectOutputStream oos=new ObjectOutputStream(file1);
                oos.writeObject(t1.projectMap);
                oos.flush();
                System.out.println("Serialized Called by Producer ");
                System.out.print("Serialized Data : ");
                for (Map.Entry<Project, ArrayList<Employee>> entry : t1.projectMap.entrySet()) {
		            Project key = entry.getKey();
		            ArrayList<Employee> employees = entry.getValue();
		        
				
				System.out.println("Project [projectCode= "+key.projectCode+", projectName= "+key.projectName+", projectStrength="+key.projectStrength+"] Has the\r\n"
						+ "following Employees");
				System.out.println("Employees...");
				System.out.print("[Employee ");
				for(Employee emp: employees)
				{
					
					System.out.print("[employeeId="+emp.EmployeeId+", employeeName="+emp.EmployeeName+", employeePhone="+emp.EmployeePhone+",\r\n"
							+ "employeeAddress="+emp.EmployeeAddress+", employeeSalary="+emp.EmployeeSalary+"]");
				}
				System.out.print("]");
				System.out.println();
				
			}
			
               
               t1.notify(); 
            }
        } catch (IOException e) {
            e.printStackTrace();
        } 
        
    
	}

}
