package Question3;


import java.util.stream.Stream;

public class IntermediateOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Stream<Integer> numbers=Stream.of(1,2,3,4,5);
		Stream<Integer> OddNumbers=numbers.filter(num->num%2!=0);
		Stream<Integer> SquareNumbers=OddNumbers.map(num->num*num);
		int sum=SquareNumbers.mapToInt(Integer::intValue).sum();
		System.out.println("Sum = "+sum);

	}

}
